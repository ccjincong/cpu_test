修改config.yaml的文件的主路径、模型路径、和SSH配置即可直接使用。

